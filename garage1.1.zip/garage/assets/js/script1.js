(function ($) {

	"use strict";

	$(function () {
		$('.btn-1')
			.on('mouseenter', function (e) {
				var parentOffset = $(this).offset(),
					relX = e.pageX - parentOffset.left,
					relY = e.pageY - parentOffset.top;
				$(this).find('span').css({ top: relY, left: relX })
			})
			.on('mouseout', function (e) {
				var parentOffset = $(this).offset(),
					relX = e.pageX - parentOffset.left,
					relY = e.pageY - parentOffset.top;
				$(this).find('span').css({ top: relY, left: relX })
			});

	});
	if (!localStorage.getItem('cart')) {
		localStorage.setItem('cart', JSON.stringify([]));
	  }
	  

	$('h4#cart-count').text(JSON.parse(localStorage.getItem('cart')).length)
	function leftOuterContainer() {
		if ($(".left-outer-container").length) {
			var windowSize = $(window).width();

			if (windowSize >= 1170) {
				var width = ($(window).width() - 1170),
					LOC = (width / 2);
				$(".left-outer-container").css("margin-left", LOC);
			}
		}
	}
	leftOuterContainer();
	
	//Hide Loading Box (Preloader)
	function handlePreloader() {
		if ($('.loader-wrap').length) {
			$('.loader-wrap').delay(1000).fadeOut(500);
		}
		TweenMax.to($(".loader-wrap .overlay"), 1.2, {
			force3D: true,
			left: "100%",
			ease: Expo.easeInOut,
		});
	}

	

	if ($(".preloader-close").length) {
		$(".preloader-close").on("click", function () {
			$('.loader-wrap').delay(200).fadeOut(500);
		})
	}

	function dynamicCurrentMenuClass(selector) {
		let FileName = window.location.href.split('/').reverse()[0];

		selector.find('li').each(function () {
			let anchor = $(this).find('a');
			if ($(anchor).attr('href') == FileName) {
				$(this).addClass('current');
			}
		});
		// if any li has .current elmnt add class
		selector.children('li').each(function () {
			if ($(this).find('.current').length) {
				$(this).addClass('current');
			}
		});
		// if no file name return 
		if ('' == FileName) {
			selector.find('li').eq(0).addClass('current');
		}
	}
	var pms = true;
	$('#pms').click(function(){
		
		if(pms == true) {
			$('.package').slideDown('slow')
			pms = false;
		}else{
			$('.package').slideUp('slow')
			pms = true;
		}
		
	});
	var crw = true;
	$('#crw').click(function(){
		
		if(crw == true) {
			$('.custom-repairs-works').slideDown('slow')
			crw = false;
		}else{
			$('.custom-repairs-works').slideUp('slow')
			crw = true;
		}
		
	});
	var bdp = true;
	$('#bdp').click(function(){
		
		if(bdp == true) {
			$('.body-work').slideDown('slow')
			bdp = false;
		}else{
			$('.body-work').slideUp('slow')
			bdp = true;
		}
		
	});
	var ars = true;
	$('#ars').click(function(){
		
		if(ars == true) {
			$('.ac-service').slideDown('slow')
			ars = false;
		}else{
			$('.ac-service').slideUp('slow')
			ars = true;
		}
		
	});
	var cdp = true;
	$('#cdp').click(function(){
		
		if(cdp == true) {
			$('.car-detailing').slideDown('slow')
			cdp = false;
		}else{
			$('.car-detailing').slideUp('slow')
			cdp = true;
		}
		
	});
	var afcw = true;
	$('#afcw').click(function(){
		
		if(afcw == true) {
			$('.access-fitment').slideDown('slow')
			afcw = false;
		}else{
			$('.access-fitment').slideUp('slow')
			afcw = true;
		}
		
	});
	$('h5.service-remove').click(function(){
		var service = JSON.parse(localStorage.getItem('cart'))
		console.log(service)
	})

	$('#submit-btn').click(function(){
        var email = $('#email').val();
		var mob = $('#mobile-no').val();
		var mess = $('#message').val();
		var name = $('#uname').val();
		var obj = {services: JSON.parse(localStorage.getItem('cart')), mobile: mob, email: email, mess: mess, name:name}
		$('#loadingmsg').css('display','block')
		
		fetch('http://127.0.0.1:4000/', {
			method: "POST",
			mode: "cors", 
			cache: "no-cache", 
			credentials: "same-origin", 
			headers: {
			  "Content-Type": "application/json",
			}, 
			body: JSON.stringify(obj), 
		  }).then(res => res.json().then(data => {
			if(data.acknowledged == true){
				alert("Your appointment has been acknowledged! We'll contact you shortly. You can go back!")
			}
			
		localStorage.setItem('cart', '[]');
		  })).catch(error => {
			alert("Error",error);
		  });
    });
	$('.services-1-block').click(function(){
		
		var value = $(this).find(".services-1-title").text()
    	var arr = JSON.parse(localStorage.getItem('cart'))
		if (!arr.includes(value)) {
			arr.push(value);
			localStorage.setItem('cart', JSON.stringify(arr));
			alert('added to cart')
		  }else{
			alert('already added to cart')
		  }
		$('h4#cart-count').text(JSON.parse(localStorage.getItem('cart')).length);
	});    
	let mainNavUL = $('.main-menu').find('.navigation');
	dynamicCurrentMenuClass(mainNavUL);


	function headerStyle() {
		if ($('.main-header').length) {
			var windowpos = $(window).scrollTop();
			var siteHeader = $('.main-header');
			var scrollLink = $('.scroll-to-top');
			var sticky_header = $('.main-header .sticky-header');
			if (windowpos > 100	) {
				siteHeader.addClass('fixed-header');
				sticky_header.addClass("animated slideInDown");
				//$('h4#cart-count').text(localStorage.getItem('cart'));
				
				scrollLink.fadeIn(300);
				
			} else {
				siteHeader.removeClass('fixed-header');
				sticky_header.removeClass("animated slideInDown");
				scrollLink.fadeOut(300);
			}
		}
	}

	headerStyle();

	//Submenu Dropdown Toggle
	if ($('.main-header li.dropdown ul').length) {
		$('.main-header .navigation li.dropdown').append('<div class="dropdown-btn"><span class="fa fa-angle-right"></span></div>');
	}

	if ($('.nav-overlay').length) {
		// / cursor /
		var cursor = $(".nav-overlay .cursor"),
			follower = $(".nav-overlay .cursor-follower");

		var posX = 0,
			posY = 0;

		var mouseX = 0,
			mouseY = 0;

		TweenMax.to({}, 0.016, {
			repeat: -1,
			onRepeat: function () {
				posX += (mouseX - posX) / 9;
				posY += (mouseY - posY) / 9;

				TweenMax.set(follower, {
					css: {
						left: posX - 22,
						top: posY - 22
					}
				});

				TweenMax.set(cursor, {
					css: {
						left: mouseX,
						top: mouseY
					}
				});

			}
		});

		$(document).on("mousemove", function (e) {
			var scrollTop = window.pageYOffset || document.documentElement.scrollTop;
			mouseX = e.pageX;
			mouseY = e.pageY - scrollTop;
		});
		$("button, a").on("mouseenter", function () {
			cursor.addClass("active");
			follower.addClass("active");
		});
		$("button, a").on("mouseleave", function () {
			cursor.removeClass("active");
			follower.removeClass("active");
		});
		$(".nav-overlay").on("mouseenter", function () {
			cursor.addClass("close-cursor");
			follower.addClass("close-cursor");
		});
		$(".nav-overlay").on("mouseleave", function () {
			cursor.removeClass("close-cursor");
			follower.removeClass("close-cursor");
		});
	}

	if ($('.mobile-menu').length) {

		var mobileMenuContent = $('.main-header .nav-outer .main-menu').html();
		$('.mobile-menu .menu-box .menu-outer').append(mobileMenuContent);
		$('.sticky-header .main-menu').append(mobileMenuContent);

		$('.mobile-menu li.dropdown .dropdown-btn').on('click', function () {
			$(this).toggleClass('open');
			$(this).prev('ul').slideToggle(500);
		});
		$('.mobile-nav-toggler').on('click', function () {
			$('body').addClass('mobile-menu-visible');
		});

		$('.mobile-menu .menu-backdrop,.mobile-menu .close-btn,.scroll-nav li a').on('click', function () {
			$('body').removeClass('mobile-menu-visible');
		});
		$('.mobile-menu-header').on('click', function () {
			$('body').removeClass('mobile-menu-visible');
		});
	}

	if ($('.side-menu').length) {

		$('.side-menu li.dropdown .dropdown-btn').on('click', function () {
			$(this).toggleClass('open');
			$(this).prev('ul').slideToggle(500);
		});

		$('body').addClass('side-menu-visible');
		$('.side-nav-toggler').on('click', function () {
			$('body').addClass('side-menu-visible');
		});

		$('.side-menu .side-menu-resize').on('click', function () {
			$('body').toggleClass('side-menu-visible');
		});

		$('.main-header .mobile-nav-toggler-two').on('click', function () {
			$('body').addClass('side-menu-visible-s2');
		});

		$('.main-header .side-menu-overlay').on('click', function () {
			$('body').removeClass('side-menu-visible-s2');
		});
	}


	function bannerSlider() {
		if ($(".banner-slider").length > 0) {

			var bannerSlider = new Swiper('.banner-slider', {
				preloadImages: false,
				loop: false,
				grabCursor: false,
				centeredSlides: false,
				resistance: true,
				resistanceRatio: 0.6,
				speed: 1400,
				spaceBetween: 0,
				parallax: false,
				effect: "slide",
				autoplay: {
					delay: 4000,
					disableOnInteraction: false
				},
				navigation: {
					nextEl: '.banner-slider-button-next',
					prevEl: '.banner-slider-button-prev',
				},
			});
		}


	}

	if ($('.theme_carousel').length) {
		$(".theme_carousel").each(function (index) {
			var $owlAttr = {},
				$extraAttr = $(this).data("options");
			$.extend($owlAttr, $extraAttr);
			$(this).owlCarousel($owlAttr);
		});
	}

	if ($('.team-1-carousel').length) {
		var team1Carousel = $('.team-1-carousel');
		team1Carousel.each(function (index) {
			var $owlAttr = {},
				$extraAttr = $(this).data("options");
			$.extend($owlAttr, $extraAttr);
			$(this).owlCarousel($owlAttr);


			var nextBtn = $('.team-1-carousel-btn .team-1-carousel-left-btn');
			var prevBtn = $('.team-1-carousel-btn .team-1-carousel-right-btn');
			nextBtn.on('click', function () {
				team1Carousel.trigger('prev.owl.carousel', [300]);
				return false;
			});
			prevBtn.on('click', function () {
				team1Carousel.trigger('next.owl.carousel', [300]);
				return false;
			});
		});
	}

	if ($('.services-3-carousel').length) {
		var services3Carousel = $('.services-3-carousel');
		services3Carousel.each(function (index) {
			var $owlAttr = {},
				$extraAttr = $(this).data("options");
			$.extend($owlAttr, $extraAttr);
			$(this).owlCarousel($owlAttr);


			var nextBtn = $('.services-3-carousel-btn .services-3-carousel-left-btn');
			var prevBtn = $('.services-3-carousel-btn .services-3-carousel-right-btn');
			nextBtn.on('click', function () {
				services3Carousel.trigger('prev.owl.carousel', [300]);
				return false;
			});
			prevBtn.on('click', function () {
				services3Carousel.trigger('next.owl.carousel', [300]);
				return false;
			});
		});
	}





	//Sortable Masonary with Filters
	function sortableMasonry() {
		if ($('.sortable-masonry').length) {
			var winDow = $(window);
			// Needed variables
			var $container = $('.sortable-masonry .items-container');
			var $filter = $('.filter-btns');
			$container.isotope({
				filter: '.all',
				animationOptions: {
					duration: 500,
					easing: 'linear'
				}
			});
			// Isotope Filter 
			$filter.find('li').on('click', function () {
				var selector = $(this).attr('data-filter');
				try {
					$container.isotope({
						filter: selector,
						animationOptions: {
							duration: 500,
							easing: 'linear',
							queue: false
						}
					});
				} catch (err) { }
				return false;
			});
			winDow.on('resize', function () {
				var selector = $filter.find('li.active').attr('data-filter');
				$container.isotope({
					filter: selector,
					animationOptions: {
						duration: 500,
						easing: 'linear',
						queue: false
					}
				});
				$container.isotope()
			});
			var filterItemA = $('.filter-btns li');
			filterItemA.on('click', function () {
				var $this = $(this);
				if (!$this.hasClass('active')) {
					filterItemA.removeClass('active');
					$this.addClass('active');
				}
			});
			$container.isotope("on", "layoutComplete", function (a, b) {
				var a = b.length,
					pcn = $(".filters .count");
				pcn.html(a);
			});
		}
	}


	// Testimonial 
	if ($('.testimonial-carousel').length) {
		var testimonialThumb = new Swiper('.testimonial-thumbs', {
			preloadImages: false,
			loop: true,
			speed: 2400,
			slidesPerView: 3,
			centeredSlides: true,
			spaceBetween: 0,
			effect: "slide",
		});
		var totalSlides = $(".swiper-container").length;
		var testimonialContent = new Swiper('.testimonial-content', {
			preloadImages: false,
			loop: true,
			speed: 2400,
			spaceBetween: 0,
			effect: "slide",
			thumbs: {
				swiper: testimonialThumb
			}

		});

	}


	

	// Isotop Layout
	function isotopeBlock() {
		if ($(".isotope-block").length) {
			var $grid = $('.isotope-block').isotope();

		}
	}

	isotopeBlock();

	if ($('.wow').length) {
		var wow = new WOW(
			{
				boxClass: 'wow',      // animated element css class (default is wow)
				animateClass: 'animated', // animation css class (default is animated)
				offset: 0,          // distance to the element when triggering the animation (default is 0)
				mobile: true,       // trigger animations on mobile devices (default is true)
				live: true       // act on asynchronously loaded content (default is true)
			}
		);
		wow.init();
	}

	//Add One Page nav
	if ($('.scroll-nav').length) {
		$('.scroll-nav ul').onePageNav();
	}

	$('.scroll-top-inner').on("click", function () {
		$('html, body').animate({ scrollTop: 0 }, 500);
		return false;
	});

	function handleScrollbar() {

		var progressLineBar = $('.scroll-top-inner .bar-inner');
		var pageHeight = $(document).height();
		var windwoHeight = $(window).height();
		var windowPos = $(window).scrollTop();
		var progressLineBarWidth = windowPos / (pageHeight - windwoHeight) * 100;
		$(progressLineBar).css('width', (progressLineBarWidth + '%'));

	}

	$(window).on('scroll', function () {
		handleScrollbar();
		if ($(window).scrollTop() > 200) {
			$('.scroll-top-inner').addClass('visible');
		} else {
			$('.scroll-top-inner').removeClass('visible');
		}
	});


	$(window).on('resize', function () {
		leftOuterContainer();
	});


	$(window).on('scroll', function () {
		headerStyle();
	});


	$(window).on('load', function () {
		handlePreloader();
		sortableMasonry();
		isotopeBlock();
		bannerSlider();
	});

})(window.jQuery);